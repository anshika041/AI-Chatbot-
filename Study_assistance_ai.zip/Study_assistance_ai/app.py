from flask import Flask, render_template, redirect, url_for, request, flash, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_bcrypt import Bcrypt
import requests
import os
import google.generativeai as genai
import json

# ────── App Configuration ────── #
app = Flask(__name__)
app.config['SECRET_KEY'] = 'AIzaSyCn6S0TtIe_fy25ICRjXgLvJSNWVIXw7b4'  # Use a secure secret in production
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# ────── Initialize Extensions ────── #
db = SQLAlchemy(app)
login_manager = LoginManager(app)
bcrypt = Bcrypt(app)
login_manager.login_view = 'login'  # Redirect to login if unauthorized

# ────── Configure Google Generative AI ────── #
API_KEY = "AIzaSyCn6S0TtIe_fy25ICRjXgLvJSNWVIXw7b4"  # Better to use environment variable
genai.configure(api_key=API_KEY)

# ────── User Model ────── #
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), nullable=False, unique=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(60), nullable=False)
    tasks = db.relationship('Task', backref='owner', lazy=True)
    
class Task(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    content = db.Column(db.String(255))
    is_done = db.Column(db.Boolean, default=False)

# ────── Routes ────── #
@app.route('/')
def home():
    return render_template('layout.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = bcrypt.generate_password_hash(request.form['password']).decode('utf-8')

        # Check if user already exists
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash('Email already registered. Please log in.', 'danger')
            return redirect(url_for('home'))

        user = User(username=username, email=email, password=password)
        db.session.add(user)
        db.session.commit()
        flash('Account created successfully! You can now log in.', 'success')
        return redirect(url_for('home'))  # ⬅ back to layout page

    return redirect(url_for('home'))  # fallback


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()

        if user and bcrypt.check_password_hash(user.password, password):
            login_user(user)
            flash(f'Welcome, {user.username}!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Login failed. Check your email and password.', 'danger')
            return redirect(url_for('home'))

    return redirect(url_for('home'))




@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html', user=current_user.username)

@app.route('/chatbot', methods=['POST'])
@login_required
def chatbot():
    try:
        # Check if the request contains JSON data
        if not request.is_json:
            return jsonify({'reply': 'Invalid request format. Please send JSON data.'}), 400
            
        user_input = request.json.get('message')
        if not user_input:
            return jsonify({'reply': 'No message provided.'}), 400
            
        # Updated to use the correct model configuration
        model = genai.GenerativeModel(model_name="gemini-1.5-pro")
        response = model.generate_content(user_input)
        
        # Ensure we're returning valid JSON
        return jsonify({'reply': response.text})
        
    except Exception as e:
        # Proper error handling
        app.logger.error(f"Error with AI model: {str(e)}")
        return jsonify({'reply': f"I'm sorry, I encountered an error: {str(e)}"}), 500

@app.route('/tasks', methods=['GET'])
@login_required
def get_tasks():
    try:
        tasks = Task.query.filter_by(user_id=current_user.id).all()
        return jsonify([{'id': task.id, 'content': task.content, 'is_done': task.is_done} for task in tasks])
    except Exception as e:
        app.logger.error(f"Error fetching tasks: {str(e)}")
        return jsonify({'error': 'Failed to fetch tasks'}), 500

@app.route('/tasks', methods=['POST'])
@login_required
def add_task():
    try:
        if not request.is_json:
            return jsonify({'success': False, 'error': 'Invalid request format'}), 400
            
        content = request.json.get('content')
        if not content:
            return jsonify({'success': False, 'error': 'No content provided'}), 400
            
        task = Task(content=content, user_id=current_user.id)
        db.session.add(task)
        db.session.commit()
        return jsonify({'success': True, 'id': task.id})
    except Exception as e:
        app.logger.error(f"Error adding task: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/tasks/<int:task_id>', methods=['DELETE'])
@login_required
def delete_task(task_id):
    try:
        task = Task.query.get_or_404(task_id)
        if task.user_id != current_user.id:
            return jsonify({'success': False, 'error': 'Unauthorized'}), 403
        db.session.delete(task)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        app.logger.error(f"Error deleting task: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/quote')
def quote():
    try:
        res = requests.get("https://zenquotes.io/api/random", timeout=5)
        data = res.json()
        quote = data[0]['q'] + " — " + data[0]['a']
        return jsonify({'quote': quote})
    except Exception as e:
        app.logger.error(f"Error fetching quote: {str(e)}")
        return jsonify({'quote': 'The best preparation for tomorrow is doing your best today. — H. Jackson Brown, Jr.'})

# ────── Error Handlers ────── #
@app.errorhandler(404)
def not_found_error(error):
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'error': 'Not found'}), 404
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()  # Roll back any failed database transactions
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'error': 'Server error'}), 500
    return render_template('500.html'), 500

# ────── Run Server ────── #
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
